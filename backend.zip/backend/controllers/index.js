const product = require('./product');
const user = require('./user');

module.exports = { product, user };