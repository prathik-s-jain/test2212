module.exports = {
  port: process.env.port || 3000,
  authCookie: 'auth-cookie',
  latestProductCount: 10
};